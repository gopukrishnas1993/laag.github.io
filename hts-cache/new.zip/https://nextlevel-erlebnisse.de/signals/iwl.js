<!doctype html>
<html lang="de-DE">
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<!-- Google Tag Manager -->
	
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-533DMX7');</script>

<!-- End Google Tag Manager -->
		
	
	
	
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v21.6 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Seite wurde nicht gefunden. - NextLevel Erlebnisse</title>
	<meta property="og:locale" content="de_DE" />
	<meta property="og:title" content="Seite wurde nicht gefunden. - NextLevel Erlebnisse" />
	<meta property="og:site_name" content="NextLevel Erlebnisse" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://nextlevel-erlebnisse.de/#website","url":"https://nextlevel-erlebnisse.de/","name":"NextLevel Erlebnisse","description":"Sandbox VR, Lasertag, Escaperoom, Hologate and more...","publisher":{"@id":"https://nextlevel-erlebnisse.de/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://nextlevel-erlebnisse.de/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"de-DE"},{"@type":"Organization","@id":"https://nextlevel-erlebnisse.de/#organization","name":"NextLevel Erlebnisse","url":"https://nextlevel-erlebnisse.de/","logo":{"@type":"ImageObject","inLanguage":"de-DE","@id":"https://nextlevel-erlebnisse.de/#/schema/logo/image/","url":"https://nextlevel-erlebnisse.de/wp-content/uploads/2021/11/NextLevelErlebnisse-_Textmarke.png","contentUrl":"https://nextlevel-erlebnisse.de/wp-content/uploads/2021/11/NextLevelErlebnisse-_Textmarke.png","width":3283,"height":1861,"caption":"NextLevel Erlebnisse"},"image":{"@id":"https://nextlevel-erlebnisse.de/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//use.typekit.net' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="NextLevel Erlebnisse &raquo; Feed" href="https://nextlevel-erlebnisse.de/feed/" />
<link rel="alternate" type="application/rss+xml" title="NextLevel Erlebnisse &raquo; Kommentar-Feed" href="https://nextlevel-erlebnisse.de/comments/feed/" />
<link rel='stylesheet' id='airi-bootstrap-css' href='https://nextlevel-erlebnisse.de/wp-content/themes/airi/css/bootstrap/bootstrap.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css' href='https://nextlevel-erlebnisse.de/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='custom-typekit-css-css' href='https://use.typekit.net/xxa5vuq.css' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://nextlevel-erlebnisse.de/wp-content/plugins/contact-form-7/includes/css/styles.css' type='text/css' media='all' />
<link rel='stylesheet' id='mc4wp-form-themes-css' href='https://nextlevel-erlebnisse.de/wp-content/plugins/mailchimp-for-wp/assets/css/form-themes.css' type='text/css' media='all' />
<link rel='stylesheet' id='cmplz-general-css' href='https://nextlevel-erlebnisse.de/wp-content/plugins/complianz-gdpr/assets/css/cookieblocker.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='parent-style-css' href='https://nextlevel-erlebnisse.de/wp-content/themes/airi/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='child-style-css' href='https://nextlevel-erlebnisse.de/wp-content/themes/airi-child/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='airi-style-css' href='https://nextlevel-erlebnisse.de/wp-content/themes/airi-child/style.css' type='text/css' media='all' />
<style id='airi-style-inline-css' type='text/css'>
h1,h2,h3,h4,h5,h6,.site-title{font-family:Work Sans;font-weight:500;}.editor-block-list__layout h1,.editor-block-list__layout h2,.editor-block-list__layout h3,.editor-block-list__layout h4,.editor-block-list__layout h5,.editor-block-list__layout h6,.editor-post-title__block .editor-post-title__input{font-family:Work Sans;font-weight:500;}body{font-family:Work Sans;font-weight:400;font-size:16px;}.editor-block-list__layout,.editor-block-list__layout .editor-block-list__block{font-family:Work Sans;font-weight:400;}.site-title{font-size:36px;}.site-description{font-size:16px;}.main-navigation ul ul li{font-size:13px;}.blog-loop .entry-title{font-size:px;}.single-post .entry-title{font-size:36px;color:#191919;}.widget-area .widget-title{font-size:24px;}.widget-area .widget{font-size:16px;}.sidebar-column .widget-title{font-size:20px;}.sidebar-column .widget{font-size:16px;}.site-info{font-size:13px;}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.product div.entry-summary p.price, .product div.entry-summary span.price,.athemes-blog:not(.airi_athemes_blog_skin) .posted-on a,.athemes-blog:not(.airi_athemes_blog_skin) .byline a:hover,.testimonials-section.style1:before,.single-post .read-more-link .gt,.blog-loop .read-more-link .gt,.single-post .posted-on a,.blog-loop .posted-on a,.entry-title a:hover,.airi_recent_entries .post-date,.menuStyle3 .top-bar .contact-item .fa,.menuStyle4 .contact-area .contact-block .contact-icon,.widget_categories li:hover::before,.widget_categories li:hover a{color:#eaa647;}.product .single_add_to_cart_button.button.alt,.menuStyle4 .contact-area .contact-block .contact-icon,button,.button,input[type="button"],input[type="reset"],input[type="submit"]{border-color:#eaa647;}.woocommerce-checkout button.button.alt,.woocommerce-checkout button.button.alt:hover,.woocommerce-cart .cart-collaterals .cart_totals .button:hover,.woocommerce-cart .cart-collaterals .cart_totals .button,.product .single_add_to_cart_button.button.alt:hover,.product .single_add_to_cart_button.button.alt,.woocommerce ul.products li.product .button,.menuStyle2 .main-navigation a:hover:after, .menuStyle2 .main-navigation .current-menu-item:after,.comments-area .comment-reply-link:hover,.menuStyle4 .main-navigation .header-cta:before,.menuStyle4 .main-navigation .header-cta,button,.button,input[type="button"],input[type="reset"],input[type="submit"],.menuStyle3 .main-navigation a:hover:after,.menuStyle3 .main-navigation .current-menu-item:after{background-color:#eaa647;}.menuStyle1 .site-title a{color:#ffffff;}.menuStyle1 .sticky-wrapper.is-sticky .site-title a{color:#000000;}.menuStyle1 .site-description{color:#ffffff;}.menuStyle1 .sticky-wrapper.is-sticky .site-description{color:#191919;}.menuStyle1 .main-navigation a, .menuStyle1 .fa-search, .menuStyle1 ul.header-search-cart li a{color:#ffffff;}.menuStyle1 .sticky-wrapper.is-sticky .main-navigation a, .menuStyle1 .sticky-wrapper.is-sticky .fa-search, .menuStyle1 .is-sticky ul.header-search-cart li a{color:#ffffff;}.menuStyle1 .site-header, .menuStyle1.page-template-template_page-builder .site-header{background-color:;}.menuStyle1 .is-sticky .site-header{background-color:#000000;}.menuStyle1 .mobile-menu-toggle_lines, .menuStyle1 .mobile-menu-toggle_lines:before, .menuStyle1 .mobile-menu-toggle_lines:after{background-color:#fff;}.menuStyle2 .site-title a{color:#191919;}.menuStyle2 .sticky-wrapper.is-sticky .site-title a{color:#191919;}.menuStyle2 .site-description{color:#707070;}.menuStyle2 .sticky-wrapper.is-sticky .site-description{color:#707070;}.menuStyle2 .main-navigation a, .menuStyle2 .header-search-toggle, .menuStyle2 .header-search-cart li a{color:#191919;}.menuStyle2 .sticky-wrapper.is-sticky .main-navigation a, .menuStyle2 .is-sticky .header-search-toggle, .menuStyle2 .is-sticky .header-search-cart li a{color:#191919;}.menuStyle2 .site-header{background-color:#fff;}.menuStyle2 .is-sticky .site-header{background-color:#ffffff;}.menuStyle2 .mobile-menu-toggle_lines, .menuStyle2 .mobile-menu-toggle_lines:before, .menuStyle2 .mobile-menu-toggle_lines:after{background-color:#212121;}.menuStyle3 .top-bar{background-color:#fff;}.menuStyle3 .top-bar a, .menuStyle3 .top-bar .contact-item.header-social .fa, .menuStyle3 .top-bar .contact-item.header-social a{color:#191919;}.menuStyle3 .top-bar .contact-item .fa-envelope, .menuStyle3 .top-bar .contact-item .fa-phone{color:#f0437e;}.menuStyle3 .top-bar .button{background-color:#f0437e;border-color:#f0437e;color:#FFF;}.menuStyle3 .top-bar .button:hover{background-color:transparent;border-color:transparent;color:#000;}.menuStyle3 .site-title a{color:#ffffff;}.menuStyle3 .sticky-wrapper.is-sticky .site-title a{color:#191919;}.menuStyle3 .site-description{color:#ffffff;}.menuStyle3 .sticky-wrapper.is-sticky .site-description{color:#191919;}.menuStyle3 .main-navigation a, .menuStyle3 .header-search-wrapper .header-search-toggle a, .menuStyle3 ul.header-search-cart li a{color:#ffffff;}.menuStyle3 .sticky-wrapper.is-sticky .main-navigation a, .menuStyle3 .is-sticky .header-search-wrapper .header-search-toggle a, .menuStyle3 .is-sticky ul.header-search-cart li a{color:#191919;}.menuStyle3 .bottom-bar, .menuStyle3.page-template-template_page-builder .bottom-bar{background-color:transparent;}.menuStyle3 .is-sticky .bottom-bar{background-color:#ffffff;}.menuStyle3 .site-header .mobile-menu-toggle_lines, .menuStyle3 .mobile-menu-active .mobile-menu-toggle .mobile-menu-toggle_lines, .menuStyle3 .site-header .mobile-menu-toggle_lines:before, .menuStyle3 .site-header .mobile-menu-toggle_lines:after{background-color:#fff;}.menuStyle4 .site-title a{color:#191919;}.menuStyle4 .site-description{color:#707070;}.menuStyle4 .main-navigation{background-color:#0e304e;}.menuStyle4 .main-navigation li a, .menuStyle4 .main-navigation .header-search-wrapper .header-search-toggle a{color:#fff;}.menuStyle4 .site-header{background-color:#fff;}.menuStyle4 .contact-area .contact-block .contact-icon{color:#f89121;border-color:#f89121;}.menuStyle4 .contact-area .contact-block span:first-of-type{color:#595959;}.menuStyle4 .contact-area .contact-block span:last-of-type{color:#0e304e;}.menuStyle4 .main-navigation .header-cta, .menuStyle4 .main-navigation .header-cta:before{background-color:#f89121;}.menuStyle4 .main-navigation .header-cta a{color:#FFF;}.menuStyle4 .mobile-menu-toggle_lines, .menuStyle4 .mobile-menu-toggle_lines:before, .menuStyle4 .mobile-menu-toggle_lines:after{background-color:#212121;}.menuStyle5 .site-title a{color:#ffffff;}.menuStyle5 .sticky-wrapper.is-sticky .site-title a{color:#191919;}.menuStyle5 .site-description{color:#ffffff;}.menuStyle5 .sticky-wrapper.is-sticky .site-description{color:#191919;}.menuStyle5 .site-header{background-color:#61a0ce;}.menuStyle5 .is-sticky .site-header{background-color:#61a0ce;}.menuStyle5 .site-header .socials a{color:#fff;}.menuStyle5 .is-sticky .site-header .socials a{color:#fff;}.menuStyle5 .site-header .contact-us{color:#fff;}.menuStyle5 .is-sticky .site-header .contact-us{color:#fff;}.menuStyle5 .mobile-menu-toggle_lines, .menuStyle5 .mobile-menu-toggle_lines:before, .menuStyle5 .mobile-menu-toggle_lines:after{background-color:#212121;}.menuStyle6 .site-header .top-section{color:#fff;border-bottom-color:#303248;}.menuStyle6 .site-title a{color:#ffffff;}.menuStyle6 .sticky-wrapper.is-sticky .site-title a{color:#fff;}.menuStyle6 .site-description{color:#ffffff;}.menuStyle6 .sticky-wrapper.is-sticky .site-description{color:#fff;}.menuStyle6 .site-header{background-color:#181b33;}.menuStyle6 .is-sticky .site-header{background-color:#171b6c;}.menuStyle6 .site-header .main-navigation .menu > li > a:after, .menuStyle6 .site-header .main-navigation .menu > ul > li > a:after{background-color:#948b3e;}.menuStyle6 .site-header .btn{border-color:#948b3e;}.menuStyle6 .site-header .mobile-menu-toggle_lines, .menuStyle6 .mobile-menu-active .mobile-menu-toggle .mobile-menu-toggle_lines, .menuStyle6 .site-header .mobile-menu-toggle_lines:before, .menuStyle6 .site-header .mobile-menu-toggle_lines:after{background-color:#fff;}#site-navigation ul ul li a{color:#1c1c1c;}#site-navigation ul ul li{background-color:#f7f7f7;}.menuStyle1 .mobile-menu-toggle_lines, .menuStyle1 .mobile-menu-toggle_lines:before, .menuStyle1 .mobile-menu-toggle_lines:after,.menuStyle1 .mobile-menu-toggle_lines,.mobile-menu-toggle_lines:before, .mobile-menu-toggle_lines:after,.mobile-menu-toggle_lines,.menuStyle3 .mobile-menu-toggle_lines,.menuStyle3 .mobile-menu-toggle_lines:before, .menuStyle3 .mobile-menu-toggle_lines:after{background:;}.entry-title a{color:#191919;}.single-post .post-cat, .blog-loop .post-cat{background-color:#eff1f4;}.single-post .entry-meta, .blog-loop .entry-meta{color:#bfbfbf;}.single-post .entry-meta .byline a, .blog-loop .entry-meta .byline a{color:#595959;}.single-post .entry-content, .blog-loop .entry-content{color:#595959;}.widget .widget-title{color:#191919;}.widget{color:#707070;}.widget a{color:#595959;}@media screen and (max-width: 1199px){.menuStyle1 .main-navigation a, .menuStyle1 .main-navigation ul li a:hover, .menuStyle1 .main-navigation ul li.current_page_item > a, .menuStyle1 .main-navigation ul li.current-menu-item > a, .menuStyle1 .main-navigation ul li.current_page_ancestor > a, .menuStyle1 .main-navigation ul li.current-menu-ancestor > a, .menuStyle1 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle1 .main-navigation ul .subnav-toggle:hover{color:#ffffff;}.menuStyle2 .site-header .main-navigation .menu li a, .menuStyle2 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle2 .main-navigation ul .subnav-toggle:hover{color:#f85757;}.menuStyle2 .main-navigation a:hover:after, .menuStyle2 .main-navigation .current-menu-item:after{background-color:#f85757;}.menuStyle3 .site-header .main-navigation .menu li a, .menuStyle3 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle3 .main-navigation ul .subnav-toggle:hover{color:#fb397d;}.menuStyle3 .main-navigation a:hover:after, .menuStyle3 .main-navigation .current-menu-item:after{background-color:#fb397d;}.menuStyle4 .site-header .main-navigation .menu li a, .menuStyle4 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle4 .main-navigation ul .subnav-toggle:hover, .menuStyle4 .main-navigation .menu > li.menu-item-has-children > .subnav-toggle{color:#fb397d;}.menuStyle5 .site-header .main-navigation .menu li a, .menuStyle5 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle5 .main-navigation ul .subnav-toggle:hover{color:#191919;}.menuStyle6 .site-header .main-navigation .menu li a, .menuStyle6 .main-navigation li.menu-item-has-children > a:hover + .subnav-toggle, .menuStyle6 .main-navigation ul .subnav-toggle:hover{color:#191919;}}@media screen and (min-width: 1200px){.menuStyle5 .site-header .main-navigation .menu li a, .menuStyle5 .header-search-toggle, .menuStyle5 ul.header-search-cart li a{color:#fff;}.menuStyle5 .is-sticky .site-header .main-navigation .menu li a, .menuStyle5 .is-sticky .header-search-toggle, .menuStyle5 .is-sticky ul.header-search-cart li a{color:#fff;}.menuStyle5 .site-header .main-navigation ul li.current-menu-item > a, .menuStyle5 .site-header .main-navigation ul li a:hover{border-bottom-color:#FFF;}.menuStyle6 .site-header .main-navigation .menu li a, .menuStyle6 .site-header .header-search-cart li, .menuStyle6 .site-header .header-search-wrapper .header-search-toggle a{color:#fff;}.menuStyle6 .is-sticky .site-header .main-navigation .menu li a, .menuStyle6 .is-sticky .site-header .header-search-cart li, .menuStyle6 .is-sticky .site-header .header-search-wrapper .header-search-toggle a{color:#fff;}}
</style>
<link rel='stylesheet' id='airi-font-awesome-css' href='https://nextlevel-erlebnisse.de/wp-content/themes/airi/css/font-awesome/css/all.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='airi-fonts-css' href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' type='text/css' media='all' />
<link rel='stylesheet' id='762baf1e875629d622708e2f2706e703-css' href='//fonts.googleapis.com/css?family=Work+Sans:500' type='text/css' media='all' />
<link rel='stylesheet' id='aaa08318714772daa18bb4bc7b24e575-css' href='//fonts.googleapis.com/css?family=Work+Sans:regular' type='text/css' media='all' />
<script type="text/javascript" src="https://nextlevel-erlebnisse.de/wp-content/cache/wpo-minify/1703182684/assets/wpo-minify-header-f5440c18.min.js" id="wpo_min-header-0-js"></script>

<!-- Von Site Kit hinzugefügtes Google-Analytics-Snippet -->
<script type="text/javascript" src="https://www.googletagmanager.com/gtag/js?id=UA-212478959-1" id="google_gtagjs-js" async></script>
<script type="text/javascript" id="google_gtagjs-js-after">
/* <![CDATA[ */
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["nextlevel-erlebnisse.de"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-212478959-1", {"anonymize_ip":true});
gtag("config", "GT-KTR3JKG");
/* ]]> */
</script>

<!-- Ende des von Site Kit hinzugefügten Google-Analytics-Snippets -->
<link rel="https://api.w.org/" href="https://nextlevel-erlebnisse.de/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nextlevel-erlebnisse.de/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.2" />
<meta name="generator" content="Site Kit by Google 1.116.0" /><style>.cmplz-hidden{display:none!important;}</style>		<script>
			document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );
		</script>
				<style>
			.no-js img.lazyload { display: none; }
			figure.wp-block-image img.lazyloading { min-width: 150px; }
							.lazyload, .lazyloading { opacity: 0; }
				.lazyloaded {
					opacity: 1;
					transition: opacity 400ms;
					transition-delay: 0ms;
				}
					</style>
					<meta name="theme-color" content="#000000">
			<link rel="icon" href="https://nextlevel-erlebnisse.de/wp-content/uploads/2021/10/nextlevel-logo-150x150.jpg" sizes="32x32" />
<link rel="icon" href="https://nextlevel-erlebnisse.de/wp-content/uploads/2021/10/nextlevel-logo-300x300.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://nextlevel-erlebnisse.de/wp-content/uploads/2021/10/nextlevel-logo-300x300.jpg" />
<meta name="msapplication-TileImage" content="https://nextlevel-erlebnisse.de/wp-content/uploads/2021/10/nextlevel-logo-300x300.jpg" />
    
    



<!-- Global site tag (gtag.js) - Google Analytics NEXTLEVEL
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KR8XZHGREP"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KR8XZHGREP');
</script>
	


 <script type="text/plain" data-service="tiktok" data-category="marketing">
 !function (w, d, t) {
   w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};

   ttq.load('C691NR8QCDCUAMIVLJ20');
   ttq.page();
 }(window, document, 'ttq');
 </script>-->

 <script type="text/plain" data-service="tiktok" data-category="marketing">
!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};

  ttq.load('CDGH29JC77U1SIT03FH0');
  ttq.page();
}(window, document, 'ttq');
</script>        


<!-- Facebook Pixel Code -->
<script type="text/plain" data-service="facebook" data-category="marketing">
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '207867664573346');
fbq('track', 'PageView');
</script>
<noscript><div class="cmplz-placeholder-parent"><img class="cmplz-placeholder-element cmplz-image" data-category="marketing" data-service="general" data-src-cmplz="https://www.facebook.com/tr?id=207867664573346&amp;ev=PageView&amp;noscript=1" height="1" width="1" style="display:none"
 src="https://nextlevel-erlebnisse.de/wp-content/plugins/complianz-gdpr/assets/images/placeholders/default-minimal.jpg" 
/></div></noscript>
<!-- End Facebook Pixel Code -->



<!-- Snap Pixel Code -->
<script type='text/javascript'>
(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function()
{a.handleRequest?a.handleRequest.apply(a,arguments):a.queue.push(arguments)};
a.queue=[];var s='script';r=t.createElement(s);r.async=!0;
r.src=n;var u=t.getElementsByTagName(s)[0];
u.parentNode.insertBefore(r,u);})(window,document,
'https://sc-static.net/scevent.min.js');

snaptr('init', '38851086-2b68-4bcb-bb83-818e3c8f3eaa', {
'user_email': '_INSERT_USER_EMAIL_'
});

snaptr('track', 'PAGE_VIEW');

</script>
<!-- End Snap Pixel Code -->

    
    
</head>

 <body data-cmplz=1 class="error404 wp-custom-logo hfeed menuStyle1 menuNotContained sticky-header elementor-default elementor-kit-226"> 


<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Zum Inhalt springen</a>

		
<header id="masthead" class="site-header">
	
	<div class="container-fluid">
		<div class="row">
		<div class="site-branding col-md-4 col-sm-6 col-9">
				                
                <a href="https://nextlevel-erlebnisse.de/" class="custom-logo-link" rel="home" aria-current="page"><img width="80" height="35"   alt="Hologate" data-src="https://nextlevel-erlebnisse.de/wp-content/uploads/logos/NextLevelErlebnisse__Logo Weiss.svg" class="custom-logo lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="><noscript><img width="80" height="35" src="https://nextlevel-erlebnisse.de/wp-content/uploads/logos/NextLevelErlebnisse__Logo Weiss.svg" class="custom-logo" alt="Hologate"></noscript></a>
                
			</div><!-- .site-branding -->

			<div class="header-mobile-menu col-md-8 col-sm-6 col-3">
				<button class="mobile-menu-toggle" aria-controls="primary-menu">
					<span class="mobile-menu-toggle_lines"></span>
					<span class="sr-only">Toggle-Menü für Mobilgeräte</span>
				</button>
			</div>			

			<div class="d-flex justify-content-end col-md-8 site-menu">
				<nav id="site-navigation" class="main-navigation">
					<div class="menu-menu-container"><ul id="menu-menu" class="menu"><li id="menu-item-8425" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8425"><a href="#">Erlebnisse</a>
<ul class="sub-menu">
	<li id="menu-item-4112" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4112"><a href="https://nextlevel-erlebnisse.de/sandboxvr/">SandboxVR</a></li>
	<li id="menu-item-245" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-245"><a href="https://hologate-alsfeld.de">Hologate</a>
	<ul class="sub-menu">
		<li id="menu-item-387" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-387"><a href="https://hologate-alsfeld.de/virtual-reality/">Virtual Reality</a></li>
		<li id="menu-item-386" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-386"><a href="https://hologate-alsfeld.de/buchen/">Buchen</a></li>
	</ul>
</li>
	<li id="menu-item-258" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-258"><a href="https://escaperoom-alsfeld.de">Escaperoom</a>
	<ul class="sub-menu">
		<li id="menu-item-375" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-375"><a href="https://escaperoom-alsfeld.de/die-wolf-gang/">Die Wolf-Gäng</a></li>
		<li id="menu-item-399" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-399"><a href="https://escaperoom-alsfeld.de/buchen/">Buchen</a></li>
	</ul>
</li>
	<li id="menu-item-259" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-259"><a href="https://lasertag-alsfeld.de">Lasertag</a>
	<ul class="sub-menu">
		<li id="menu-item-267" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-267"><a href="https://lasertag-alsfeld.de/das-spiel/">Das Spiel</a></li>
		<li id="menu-item-271" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-271"><a href="https://lasertag-alsfeld.de/buchen/">Buchen</a></li>
	</ul>
</li>
	<li id="menu-item-1316" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1316"><a href="https://nextlevel-erlebnisse.de/lue/">Lü</a></li>
</ul>
</li>
<li id="menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-359"><a href="https://nextlevel-erlebnisse.de/events/">Events</a>
<ul class="sub-menu">
	<li id="menu-item-360" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-360"><a href="https://nextlevel-erlebnisse.de/events/kindergeburtstag/">Kindergeburtstag</a></li>
	<li id="menu-item-361" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-361"><a href="https://nextlevel-erlebnisse.de/events/junggesellenabschied/">Junggesellenabschied</a></li>
	<li id="menu-item-814" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-814"><a href="https://nextlevel-erlebnisse.de/firmenevent/">Firmenevent</a></li>
	<li id="menu-item-6369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6369"><a href="https://nextlevel-erlebnisse.de/events/vereine/">Vereine &amp; Gruppen</a></li>
	<li id="menu-item-7492" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7492"><a href="https://nextlevel-erlebnisse.de/seminare/">VR Seminare</a></li>
	<li id="menu-item-6370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6370"><a href="https://nextlevel-erlebnisse.de/events/schulklassen/">Schulklassen</a></li>
	<li id="menu-item-739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-739"><a href="https://nextlevel-erlebnisse.de/nextlevelclub/">NextLevel Club</a></li>
</ul>
</li>
<li id="menu-item-4706" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4706"><a href="https://nextlevel-erlebnisse.de/buchen/">Buchen</a></li>
</ul></div>                    
                    
                    
				</nav><!-- #site-navigation -->
                
                
							</div>
		</div>
	</div>
	


</header><!-- #masthead -->
	<div id="content" class="site-content">

	<div class="container"><div class="row">
	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">404</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>Es wurde nichts gefunden. Versuche es mit einem der folgenden Links oder der Suchfunktion.</p>

					<form role="search" method="get" class="search-form" action="https://nextlevel-erlebnisse.de/">
				<label>
					<span class="screen-reader-text">Suche nach:</span>
					<input type="search" class="search-field" placeholder="Suche &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Suche" />
			</form>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->

	</div></div>
	
	
	

        <style>
        #sidebar-footer {color:#999;background-color:#000}
        .social-links i {margin:10px 0.5em;}
        .kontakt-links i {margin:0 0.3em;}
        #sidebar-footer h4 {color:#999}
        #sidebar-footer a {color:#fff;text-decoration:none}
        
        #sidebar-footer .sidebar-column {text-align:center;margin-top:2em;}
        
        @media only screen and (min-width: 768px) {
        #sidebar-footer .sidebar-column:first-child {text-align:left}
        #sidebar-footer .sidebar-column:last-child {text-align:right}
        }
        
        
        </style>

    	<div id="sidebar-footer" class="footer-widgets" role="complementary">
        
        <div class="container">
            <div class="row"  style="text-align:center;margin-bottom:2em;">
                <div class="sidebar-column col-md-12 social-links" style="text-align:center">
                   <h4>Folge uns</h4>
                   <div style="font-size:2em;">
                   <a href="https://www.instagram.com/nextlevel.erlebnisse/" target="_blank"><i class="fab fa-instagram"></i></a> 
                   <a href="https://www.facebook.com/nextlevel.erlebnisse/" target="_blank"><i class="fab fa-facebook-square"></i></a> 
                   <a href="https://wa.me/4966317882336" target="_blank"><i class="fab fa-whatsapp"></i></a> 
                   <a href="https://www.twitch.tv/lasertag_alsfeld/" target="_blank"><i class="fab fa-twitch"></i></a>
                   <a href="https://www.tiktok.com/@nextlevel.erlebnisse" target="_blank"><i class="fab fa-tiktok"></i></a>
                   <a href="https://discord.gg/GK4M5W3KyR" target="_blank"><i class="fab fa-discord"></i></a>
                   <a href="https://www.youtube.com/channel/UCNRf9x4LWQV2RuXASWX6jYA" target="_blank"><i class="fab fa-youtube"></i></a>
                   
                </div>
            </div>
        </div>
        
		<div class="container">
			<div class="row">
			
				<div class="sidebar-column col-md-4 kontakt-links">
					<h4>Kontakt</h3>
                    <a href="mailto:buchung@nextlevel-erlebnisse.de" target="_blank"><i class="far fa-envelope"></i>   buchung@nextlevel-erlebnisse.de</a><br/>
                    <a href="tel:066317882663" target="_blank"><i class="fas fa-phone-square"></i>   06631 7882663</a><br/>
                    <a href="https://wa.me/4966317882663" target="_blank"><i class="fab fa-whatsapp"></i>   06631 7882663</a> <br/>
                    <br/>
                    <a href="https://nextlevel-erlebnisse.de/impressum" >Impressum</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/datenschutz">Datenschutzerklärung</a><br/>

				</div>
			
			
				<div class="sidebar-column col-md-4">
					<h4>Next Level Erlebnisse</h3>
                    <a href="https://nextlevel-erlebnisse.de/sandboxvr">Sandbox VR</a><br/>
                    <a href="https://escaperoom-alsfeld.de">Escape-Room </a><br/>
                    <a href="https://lasertag-alsfeld.de">Lasertag </a><br/>
                    <a href="https://hologate-alsfeld">Hologate </a><br/>
                    <a href="https://nextlevel-erlebnisse.de/lue">Lü</a><br/>
                  <!--  <a href="https://nextlevel-erlebnisse.de/robomaster">Robomaster Battle Alsfeld</a><br/>-->
                    
				</div>
			
			
				<div class="sidebar-column col-md-4">
					<h4>Eventangebote</h4>
                    <a href="https://nextlevel-erlebnisse.de/firmenevent">Firmenevents</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/events/kindergeburtstag">Kindergeburtstage</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/firmenevent">Teamevents</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/events/junggesellenabschied">Junggesellenabschiede</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/events/weihnachtsfeiern">Weihnachtsfeiern</a><br/>
                    <a href="https://nextlevel-erlebnisse.de/seminare">Seminare</a><br/>
				</div>
			
	
			</div>	
		</div>	
        
        <div class="container">
			<div class="row">
			
				<div style="display:flex;width: 80%;margin: 5em 10%;flex-wrap: nowrap;margin-top: 10em;}">
                    <a follow="nofollow" href="http://ec.europa.eu/agriculture/index_de.htm" target="_blank" ><img data-src='https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos1.jpg' class='lazyload' src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' /><noscript><img src="https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos1.jpg" /></noscript></a>
                    <a follow="nofollow" href="http://www.eler.hessen.de" target="_blank" ><img data-src='https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos2.jpg' class='lazyload' src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' /><noscript><img src="https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos2.jpg" /></noscript></a>
                    <a follow="nofollow" href="#"><img data-src='https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos3.jpg' class='lazyload' src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' /><noscript><img src="https://nextlevel-erlebnisse.de/wp-content/uploads/2023/01/leader_logos3.jpg" /></noscript></a>
				</div>
			
			

	
			</div>	
		</div>	

	</div>


    <!--
	<div id="sidebar-footer" class="footer-widgets" role="complementary">
		<div class="container">
			<div class="row">
							<div class="sidebar-column col-md-4">
					X<section id="text-2" class="widget widget_text">			<div class="textwidget"><p>NextLevel Erlebnisse is home of Lasertag, Escaperoom, Hologate, Robomaster Battle and many more exiting new adventures for the whole familie</p>
<p><span style="color: #bfbfbf;">@2021 NextLevel Erlebnisse</span></p>
</div>
		</section>				</div>
				
							<div class="sidebar-column col-md-4">
					X<section id="block-2" class="widget widget_block">
<h2 class="wp-block-heading">Kontakt</h2>
</section><section id="block-3" class="widget widget_block widget_text">
<p><span style="color: #bfbfbf;">E-Mail:</span> info@lasertag-alsfeld.de <br><span style="color: #bfbfbf;">Telefon:</span> (+49) 6631 7882663 <br><span style="color: #bfbfbf;">Addresse:</span> Jahnstr. 14, 36304 Alsfeld</p>
</section>				</div>
				
							<div class="sidebar-column col-md-4">
					X<section id="nav_menu-1" class="widget widget_nav_menu"><h3 class="widget-title">Wichtige Infos</h3><div class="menu-quick-links-container"><ul id="menu-quick-links" class="menu"><li id="menu-item-364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-364"><a href="https://nextlevel-erlebnisse.de/kontakt/">Kontakt</a></li>
<li id="menu-item-363" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-363"><a href="https://nextlevel-erlebnisse.de/impressum/">Impressum</a></li>
<li id="menu-item-362" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-362"><a rel="privacy-policy" href="https://nextlevel-erlebnisse.de/datenschutz/">Datenschutzerklärung</a></li>
<li id="menu-item-374" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-374"><a href="https://nextlevel-erlebnisse.de/newsletter/">Newsletter</a></li>
</ul></div></section>				</div>
										<div class="sidebar-column col-md-4">
					X<section id="athemes_social_widget-1" class="widget widget_athemes_social_widget">        <h3 class="widget-title">Folge uns</h3>        <div class="menu-social-container"><ul id="menu-social" class="menu social-media-list clearfix"><li id="menu-item-176" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-176"><a href="https://facebook.com/lasertagalsfeld"><span class="screen-reader-text">Facebook</span></a></li>
<li id="menu-item-177" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-177"><a href="https://twitter.com"><span class="screen-reader-text">Twitter</span></a></li>
<li id="menu-item-178" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-178"><a href="http://instagram.com/lasertag_alsfeld"><span class="screen-reader-text">Instagram</span></a></li>
<li id="menu-item-179" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-179"><a href="https://linkedin.com"><span class="screen-reader-text">Linkedin</span></a></li>
</ul></div>        </section>				</div>
					
			</div>	
		</div>	
	</div>-->
    
    
	<footer id="colophon" class="site-footer">
		<div class="container">
			<div class="row">
							</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->


<!-- Consent Management powered by Complianz | GDPR/CCPA Cookie Consent https://wordpress.org/plugins/complianz-gdpr -->
<div id="cmplz-cookiebanner-container"><div class="cmplz-cookiebanner cmplz-hidden banner-1 optin cmplz-bottom-right cmplz-categories-type-view-preferences" aria-modal="true" data-nosnippet="true" role="dialog" aria-live="polite" aria-labelledby="cmplz-header-1-optin" aria-describedby="cmplz-message-1-optin">
	<div class="cmplz-header">
		<div class="cmplz-logo"></div>
		<div class="cmplz-title" id="cmplz-header-1-optin">Cookie-Zustimmung verwalten</div>
		<div class="cmplz-close" tabindex="0" role="button" aria-label="close-dialog">
			<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="times" class="svg-inline--fa fa-times fa-w-11" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512"><path fill="currentColor" d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path></svg>
		</div>
	</div>

	<div class="cmplz-divider cmplz-divider-header"></div>
	<div class="cmplz-body">
		<div class="cmplz-message" id="cmplz-message-1-optin">Wir verwenden Technologien wie Cookies, um Geräteinformationen zu speichern und/oder darauf zuzugreifen. Wir tun dies, um das Browsing-Erlebnis zu verbessern und um (nicht) personalisierte Werbung anzuzeigen. Wenn du nicht zustimmst oder die Zustimmung widerrufst, kann dies bestimmte Merkmale und Funktionen beeinträchtigen.</div>
		<!-- categories start -->
		<div class="cmplz-categories">
			<details class="cmplz-category cmplz-functional" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Funktional</span>
							<span class='cmplz-always-active'>
								<span class="cmplz-banner-checkbox">
									<input type="checkbox"
										   id="cmplz-functional-optin"
										   data-category="cmplz_functional"
										   class="cmplz-consent-checkbox cmplz-functional"
										   size="40"
										   value="1"/>
									<label class="cmplz-label" for="cmplz-functional-optin" tabindex="0"><span class="screen-reader-text">Funktional</span></label>
								</span>
								Immer aktiv							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-functional">Die technische Speicherung oder der Zugang ist unbedingt erforderlich für den rechtmäßigen Zweck, die Nutzung eines bestimmten Dienstes zu ermöglichen, der vom Teilnehmer oder Nutzer ausdrücklich gewünscht wird, oder für den alleinigen Zweck, die Übertragung einer Nachricht über ein elektronisches Kommunikationsnetz durchzuführen.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-preferences" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Vorlieben</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-preferences-optin"
									   data-category="cmplz_preferences"
									   class="cmplz-consent-checkbox cmplz-preferences"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-preferences-optin" tabindex="0"><span class="screen-reader-text">Vorlieben</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-preferences">Die technische Speicherung oder der Zugriff ist für den rechtmäßigen Zweck der Speicherung von Präferenzen erforderlich, die nicht vom Abonnenten oder Benutzer angefordert wurden.</span>
				</div>
			</details>

			<details class="cmplz-category cmplz-statistics" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Statistiken</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-statistics-optin"
									   data-category="cmplz_statistics"
									   class="cmplz-consent-checkbox cmplz-statistics"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-statistics-optin" tabindex="0"><span class="screen-reader-text">Statistiken</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-statistics">Die technische Speicherung oder der Zugriff, der ausschließlich zu statistischen Zwecken erfolgt.</span>
					<span class="cmplz-description-statistics-anonymous">Die technische Speicherung oder der Zugriff, der ausschließlich zu anonymen statistischen Zwecken verwendet wird. Ohne eine Vorladung, die freiwillige Zustimmung deines Internetdienstanbieters oder zusätzliche Aufzeichnungen von Dritten können die zu diesem Zweck gespeicherten oder abgerufenen Informationen allein in der Regel nicht dazu verwendet werden, dich zu identifizieren.</span>
				</div>
			</details>
			<details class="cmplz-category cmplz-marketing" >
				<summary>
						<span class="cmplz-category-header">
							<span class="cmplz-category-title">Marketing</span>
							<span class="cmplz-banner-checkbox">
								<input type="checkbox"
									   id="cmplz-marketing-optin"
									   data-category="cmplz_marketing"
									   class="cmplz-consent-checkbox cmplz-marketing"
									   size="40"
									   value="1"/>
								<label class="cmplz-label" for="cmplz-marketing-optin" tabindex="0"><span class="screen-reader-text">Marketing</span></label>
							</span>
							<span class="cmplz-icon cmplz-open">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"  height="18" ><path d="M224 416c-8.188 0-16.38-3.125-22.62-9.375l-192-192c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0L224 338.8l169.4-169.4c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25l-192 192C240.4 412.9 232.2 416 224 416z"/></svg>
							</span>
						</span>
				</summary>
				<div class="cmplz-description">
					<span class="cmplz-description-marketing">Die technische Speicherung oder der Zugriff ist erforderlich, um Nutzerprofile zu erstellen, um Werbung zu versenden oder um den Nutzer auf einer Website oder über mehrere Websites hinweg zu ähnlichen Marketingzwecken zu verfolgen.</span>
				</div>
			</details>
		</div><!-- categories end -->
			</div>

	<div class="cmplz-links cmplz-information">
		<a class="cmplz-link cmplz-manage-options cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">Optionen verwalten</a>
		<a class="cmplz-link cmplz-manage-third-parties cookie-statement" href="#" data-relative_url="#cmplz-cookies-overview">Dienste verwalten</a>
		<a class="cmplz-link cmplz-manage-vendors tcf cookie-statement" href="#" data-relative_url="#cmplz-tcf-wrapper">Manage {vendor_count} vendors</a>
		<a class="cmplz-link cmplz-external cmplz-read-more-purposes tcf" target="_blank" rel="noopener noreferrer nofollow" href="https://cookiedatabase.org/tcf/purposes/">Lese mehr über diese Zwecke</a>
			</div>

	<div class="cmplz-divider cmplz-footer"></div>

	<div class="cmplz-buttons">
		<button class="cmplz-btn cmplz-accept">Akzeptieren</button>
		<button class="cmplz-btn cmplz-deny">Ablehnen</button>
		<button class="cmplz-btn cmplz-view-preferences">Einstellungen ansehen</button>
		<button class="cmplz-btn cmplz-save-preferences">Einstellungen speichern</button>
		<a class="cmplz-btn cmplz-manage-options tcf cookie-statement" href="#" data-relative_url="#cmplz-manage-consent-container">Einstellungen ansehen</a>
			</div>

	<div class="cmplz-links cmplz-documents">
		<a class="cmplz-link cookie-statement" href="#" data-relative_url="">{title}</a>
		<a class="cmplz-link privacy-statement" href="#" data-relative_url="">{title}</a>
		<a class="cmplz-link impressum" href="#" data-relative_url="">{title}</a>
			</div>

</div>
</div>
					<div id="cmplz-manage-consent" data-nosnippet="true"><button class="cmplz-btn cmplz-hidden cmplz-manage-consent manage-consent-1">Zustimmung verwalten</button>

</div><script>
window.addEventListener('elementor/frontend/init', function() {
elementorFrontend.hooks.addFilter( 'frontend/handlers/menu_anchor/scroll_top_distance', function( scrollTop ) {
return scrollTop - 90;
} );
} );
</script>
<script>
document.addEventListener( 'wpcf7mailsent', function ( event ) {
    gtag( 'event', 'wpcf7_submission', {
        'event_category': event.detail.contactFormId,
        'event_label': event.detail.unitTag
    } );
}, false );
</script>
<script type="text/javascript" id="wpo_min-footer-0-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/nextlevel-erlebnisse.de\/wp-json\/","namespace":"contact-form-7\/v1"},"cached":"1"};
var complianz = {"prefix":"cmplz_rt_","user_banner_id":"1","set_cookies":[],"block_ajax_content":"","banner_version":"96","version":"6.5.5","store_consent":"","do_not_track_enabled":"","consenttype":"optin","region":"eu","geoip":"","dismiss_timeout":"","disable_cookiebanner":"","soft_cookiewall":"","dismiss_on_scroll":"","cookie_expiry":"365","url":"https:\/\/nextlevel-erlebnisse.de\/wp-json\/complianz\/v1\/","locale":"lang=de&locale=de_DE","set_cookies_on_root":"","cookie_domain":"","current_policy_id":"64","cookie_path":"\/","categories":{"statistics":"Statistiken","marketing":"Marketing"},"tcf_active":"","placeholdertext":"Klicke hier, um {category}-Cookies zu akzeptieren und diesen Inhalt zu aktivieren","aria_label":"Klicke hier, um {category}-Cookies zu akzeptieren und diesen Inhalt zu aktivieren","css_file":"https:\/\/nextlevel-erlebnisse.de\/wp-content\/uploads\/complianz\/css\/banner-{banner_id}-{type}.css?v=96","page_links":{"eu":{"cookie-statement":{"title":"Cookie-Richtlinie ","url":"https:\/\/nextlevel-erlebnisse.de\/cookie-richtlinie-eu\/"},"privacy-statement":{"title":"Datenschutzerkl\u00e4rung","url":"https:\/\/nextlevel-erlebnisse.de\/datenschutz\/"},"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"us":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"uk":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"ca":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"au":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"za":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}},"br":{"impressum":{"title":"Impressum","url":"https:\/\/nextlevel-erlebnisse.de\/impressum\/"}}},"tm_categories":"1","forceEnableStats":"","preview":"","clean_cookies":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://nextlevel-erlebnisse.de/wp-content/cache/wpo-minify/1703182684/assets/wpo-minify-footer-43502e08.min.js" id="wpo_min-footer-0-js"></script>

<!--<script id="regiondo-js" src="https://cdn.regiondo.net/js/integration/bookingwidget/bookingwidget.js"></script>-->

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-533DMX7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

</body>
</html>
